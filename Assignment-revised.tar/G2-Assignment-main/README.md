# G2-Assignment
G2-Infra-SRE assignment

Login to AWS account and then follow the procedure below;

Step 1: To create an IAM policy for pushing objects to s3 and DynamoDB from the AWS Lambda function with name: aws-lambda-random-grading.
Alter the below json as per your account details. Ensure to have S3 bucket and DynamoDB resources created prior.

{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:PutObject",
        "s3:GetBucketLocation",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::aws-lambda-app/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "dynamodb:PutItem",
        "dynamodb:GetItem",
        "dynamodb:UpdateItem",
        "dynamodb:BatchWriteItem",
        "dynamodb:Query",
        "dynamodb:Scan"
      ],
      "Resource": "arn:aws:dynamodb:ap-south-1:your-account-id:table/grading"
    }
  ]
}


Step 2: To create IAM role with policy attached which we created in Step-1

Step 3: Create Lambda Function with Cloudwatch Events trigger. Script name : random_number_grading.py 

Step 4: Create SNS topic and create the subscription channel for the team members.

Step 5: Add the destination as SNS Topic in the Lambda Function. (On Failure the  SNS topic is invoked)

Step 6: Add source for lambda function as EventBridge Scheduler for triggering the function on a daily basis.

